## Backup XForms from UR-DEV
This folder contains exports of the DOI-related XForms on UR-DEV before deleting them in order to start fresh. There are also screenshots of what the form looked like.

Forms were deleted due to a problem outlined in [Library Systems Support #435](https://github.com/isdapps/library-systems-support/issues/435).