## Contents
### JATS
* **Default:** jats_to_mods_30.xsl
* **Variants:**
   - cambridge.xsl
   - nrccanada.xsl
   - aps.xsl _(formerly ATYPON)_