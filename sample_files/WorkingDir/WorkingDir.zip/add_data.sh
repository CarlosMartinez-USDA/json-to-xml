for file in *.json; do
  sed -i '1i <data>' "$file" &&
  echo '</data>' >> "$file"
done